#include <test_item.h>
#include <global.h>
#include "gpio-regs.h"
#include "dependency.h"
#include <io.h>
#include <genlib.h>

extern struct test_item_container general_container; 
extern struct test_item_container irq_container;
extern struct test_item_container port_container;
extern struct test_item_container sensitive_container;
extern struct test_item_container fl_rh_container;
extern struct test_item_container low_falling_container;
extern struct test_item_container high_rising_container;
extern struct test_item_container single_both_container;
extern struct test_item_container irq_type_select_container;
extern struct test_item_container port_item_container;
extern struct test_item_container flash_led_container;


int extern_irq_flag;
int edge_flag;
int level_flag ;

static inline void
gpio_write(u32 reg, u32 value, u32 base)
{
	base = base + reg;
	iowrite32(value, base);
}

static inline  u32
gpio_read(u32 reg, u32 base)
{
	u32 val;

	base = base + reg;
	val = ioread32(base);
	return val;
}


extern int 
normal_mode_test(int autotest)
{
	int ret = 0;
	ret = test_item_ctrl(&flash_led_container, autotest);
	return ret;
}

extern int 
flash_led_test(int autotest)
{
	int ret = 0;
	int j; 
	gpio_write(SOCLE_GPIO_PACON, SOCLE_GPIO_OUTPUT, SOCLE_GPIO_BASE);		//set port A direction register->OUTPUT
for(j=0;j<=7;j++)
{	
	gpio_write(SOCLE_GPIO_PADR, SOCLE_GPIO_DATA5<<j, SOCLE_GPIO_BASE);	//left-shift
  	USDELAY(65535);
}

  for(j=7;j>=0;j--)
{	
	gpio_write(SOCLE_GPIO_PADR, SOCLE_GPIO_DATA5<<j, SOCLE_GPIO_BASE);	//right-shift
  	USDELAY(65535);
}

	gpio_write(SOCLE_GPIO_PADR, SOCLE_GPIO_DATA4, SOCLE_GPIO_BASE);		//turn on all leds
	USDELAY(65535);
	USDELAY(65535);
	gpio_write(SOCLE_GPIO_PADR, SOCLE_GPIO_DATA3, SOCLE_GPIO_BASE);		//turn off all leds

	return ret;
	return ret;
}





extern int 
gpio_main_test(int autotest)
{
	int ret = 0;
	ret = test_item_ctrl(&general_container, autotest);
	return ret;
}

extern int 
test_mode_test(int autotest)
{
	int ret = 0;
	ret = test_item_ctrl(&irq_container, autotest);
	return ret;
}

extern int 
without_interrupt_test(int autotest)
{
	int ret = 0;
	ret = test_item_ctrl(&port_container, autotest);
	return ret;
}

/******************without irq test********************/
	/*********B->A loopback*********/
extern int 
port_item_test_1(int autotest)
{
	int ret = 0;
	u32 data_a;
	u32 data_b;
	gpio_write(GPIO_MODE_SEL, GPIO_B_A, GPIO_CDK_BASE);		
	gpio_write(GPIO_PBDR, GPIO_PBDR_DATA, GPIO_CDK_BASE);
	
	gpio_write(GPIO_PBCON, GPIO_PBCON_OUTPUT, GPIO_CDK_BASE);
	gpio_write(GPIO_PACON, GPIO_PACON_INPUT, GPIO_CDK_BASE);
	data_a = gpio_read(GPIO_PADR, GPIO_CDK_BASE);
	data_b = gpio_read(GPIO_PBDR, GPIO_CDK_BASE);
	
	//printf("\nwrite data b = %0x\n", data_b);
	printf("\nread data a = %0x\n", data_a);

	return ret;
}
	/*********A->B loopback*********/
extern int 
port_item_test_2(int autotest)
{
	int ret = 0;
	u32 data_a;
	u32 data_b;
	gpio_write(GPIO_MODE_SEL, GPIO_A_B, GPIO_CDK_BASE);		
	gpio_write(GPIO_PADR, GPIO_PADR_DATA, GPIO_CDK_BASE);
	
	gpio_write(GPIO_PACON, GPIO_PACON_OUTPUT, GPIO_CDK_BASE);
	gpio_write(GPIO_PBCON, GPIO_PBCON_INPUT, GPIO_CDK_BASE);
	data_b = gpio_read(GPIO_PBDR, GPIO_CDK_BASE);
	data_a = gpio_read(GPIO_PADR, GPIO_CDK_BASE);	

	printf("\nread data b = %0x\n", data_b);
	//printf("\nwrite data a = %0x\n", data_a);

	return ret;
}
	/*********D->C loopback*********/
extern int 
port_item_test_3(int autotest)
{
	int ret = 0;
	u32 data_d;
	u32 data_c;
	gpio_write(GPIO_MODE_SEL, GPIO_D_C, GPIO_CDK_BASE);		
	gpio_write(GPIO_PDDR, GPIO_PDDR_DATA, GPIO_CDK_BASE);
	
	gpio_write(GPIO_PDCON, GPIO_PDCON_OUTPUT, GPIO_CDK_BASE);
	gpio_write(GPIO_PCCON, GPIO_PCCON_INPUT, GPIO_CDK_BASE);
	data_c = gpio_read(GPIO_PCDR, GPIO_CDK_BASE);
	data_d = gpio_read(GPIO_PDDR, GPIO_CDK_BASE);
	
	printf("\nread data c = %0x\n", data_c);
	//printf("\nwrite data d = %0x\n", data_d);

	return ret;
}

extern int 
port_item_test_4(int autotest)
{
	int ret = 0;
	u32 data_d;
	u32 data_c;
	gpio_write(GPIO_MODE_SEL, GPIO_C_D, GPIO_CDK_BASE);		
	gpio_write(GPIO_PCDR, GPIO_PCDR_DATA, GPIO_CDK_BASE);
	
	gpio_write(GPIO_PCCON, GPIO_PCCON_OUTPUT, GPIO_CDK_BASE);
	gpio_write(GPIO_PDCON, GPIO_PDCON_INPUT, GPIO_CDK_BASE);
	data_d = gpio_read(GPIO_PDDR, GPIO_CDK_BASE);
	data_c = gpio_read(GPIO_PCDR, GPIO_CDK_BASE);
	
	printf("\nread data d = %0x\n", data_d);
	//printf("\nwrite data c = %0x\n", data_c);

	return ret;
}

extern int 
irq_type_select_test(int autotest)
{
	int ret = 0;
	ret = test_item_ctrl(&irq_type_select_container, autotest);
	return ret;
}

extern int
inter_irq_test(int autotest)
{
	int ret = 0;
	extern_irq_flag = 0;
	ret = test_item_ctrl(&port_item_container, autotest);
	return ret;
}

/********************inter irq test*********************/

extern int 
from_b_to_a_test(int autotest)
{
	int ret = 0;
	//u32 before_irq;
	u32 irq;
	u32 data_a;		u32 data_b;

	gpio_write(GPIO_MODE_SEL, GPIO_B_A, GPIO_BASE);		
	gpio_write(GPIO_MASK_SEL, GPIO_MASK_EN, GPIO_BASE);

	gpio_write(GPIO_CLEAR_A, GPIO_CLEAR_SET, GPIO_BASE);
	gpio_write(GPIO_CLEAR_B, GPIO_CLEAR_SET, GPIO_BASE);	

	gpio_write(GPIO_SENS_SEL, GPIO_LEVEL, GPIO_BASE);
	gpio_write(GPIO_LF_HR_SEL, GPIO_LOW_FALL, GPIO_BASE);

	gpio_write(GPIO_PACON, GPIO_PACON_INPUT, GPIO_BASE);
	gpio_write(GPIO_PADR, GPIO_DATA_CLR, GPIO_BASE);
	gpio_write(GPIO_PBCON, GPIO_PBCON_OUTPUT, GPIO_BASE);
	gpio_write(GPIO_PBDR, GPIO_DATA_CLR, GPIO_BASE);
	//before_irq = gpio_read(GPIO_ISR, GPIO_BASE);
	/*	B->A trigger(low level)	*/
	gpio_write(GPIO_PBDR, GPIO_PBDR_DATA, GPIO_BASE);
	data_a = gpio_read(GPIO_PADR, GPIO_BASE);
	irq = gpio_read(GPIO_ISR, GPIO_BASE);
	data_b = gpio_read(GPIO_PBDR, GPIO_BASE);

	//printf("before irq = %0x\n", before_irq);
	printf("data b = %0x\n", data_b);
	printf("irq = %0x\n", irq);
	printf("data a = %0x\n", data_a);

	return ret;
}

extern int 
from_a_to_b_test(int autotest)
{
	int ret = 0;
	u32 irq;
	u32 data_a;		u32 data_b;
	/*	A->B trigger(high level)	*/
	gpio_write(GPIO_MASK_SEL, GPIO_MASK_EN, GPIO_BASE);
        gpio_write(GPIO_MASKB_SEL, GPIO_MASK_EN, GPIO_BASE);
	gpio_write(GPIO_CLEAR_A, GPIO_CLEAR_SET, GPIO_BASE);
	gpio_write(GPIO_CLEAR_B, GPIO_CLEAR_SET, GPIO_BASE);

	gpio_write(GPIO_SENSB_SEL, GPIO_LEVEL, GPIO_BASE);
	gpio_write(GPIO_LF_HRB_SEL, GPIO_HIGH_RISE, GPIO_BASE);
	
	gpio_write(GPIO_MODE_SEL, GPIO_A_B, GPIO_BASE);	
	gpio_write(GPIO_PACON, GPIO_PACON_OUTPUT, GPIO_BASE);
	gpio_write(GPIO_PADR, GPIO_DATA_CLR, GPIO_BASE);
	gpio_write(GPIO_PBCON, GPIO_PBCON_INPUT, GPIO_BASE);
	gpio_write(GPIO_PBDR, GPIO_DATA_CLR, GPIO_BASE);	
	
	gpio_write(GPIO_PADR, GPIO_PADR_DATA, GPIO_BASE);
	data_b = gpio_read(GPIO_PBDR, GPIO_BASE);
	data_a = gpio_read(GPIO_PADR, GPIO_BASE);
        irq = gpio_read(GPIO_ISR, GPIO_BASE);
	
	printf("data b = %0x\n", data_b);
	printf("irq = %0x\n", irq);
	printf("data a = %0x\n", data_a);

	return ret;
}
/***************	CD NOT USE	***************/
extern int 
from_c_to_d_test(int autotest)
{
	int ret = 0;
	//u32 before_irq;		u32 irq;
	u32 data_c;		u32 data_d;

	gpio_write(GPIO_CLEAR_C, GPIO_CLEAR_SET, GPIO_BASE);
	gpio_write(GPIO_CLEAR_D, GPIO_CLEAR_SET, GPIO_BASE);

	gpio_write(GPIO_MODE_SEL, GPIO_C_D, GPIO_BASE);		
	gpio_write(GPIO_MASKD_SEL, GPIO_MASK_EN, GPIO_BASE);
	gpio_write(GPIO_MASKC_SEL, GPIO_MASK_EN, GPIO_BASE);
	gpio_write(GPIO_SENS_SEL, GPIO_EDGE, GPIO_BASE);
	gpio_write(GPIO_LF_HR_SEL, GPIO_HIGH_RISE, GPIO_BASE);
	gpio_write(GPIO_PCCON, GPIO_PCCON_OUTPUT, GPIO_BASE);
	gpio_write(GPIO_PDCON, GPIO_PDCON_INPUT, GPIO_BASE);
	//before_irq = gpio_read(GPIO_ISR, GPIO_BASE);
	/*	C->D trigger(rising edge)	*/
	gpio_write(GPIO_PCDR, GPIO_PCDR_DATA, GPIO_BASE);
	data_d = gpio_read(GPIO_PDDR, GPIO_BASE);
	//irq = gpio_read(GPIO_ISR, GPIO_BASE);
	data_c = gpio_read(GPIO_PCDR, GPIO_BASE);
	
	//printf("before irq = %0x\n", before_irq);
	printf("data c = %0x\n", data_c);
	//printf("irq = %0x\n", irq);
	printf("data d = %0x\n", data_d);

	return ret;
}

extern int 
from_d_to_c_test(int autotest)
{
	int ret = 0;
	//u32 before_irq;		u32 irq;
	u32 data_c;		u32 data_d;

	gpio_write(GPIO_CLEAR_C, GPIO_CLEAR_SET, GPIO_BASE);
	gpio_write(GPIO_CLEAR_D, GPIO_CLEAR_SET, GPIO_BASE);

	gpio_write(GPIO_MODE_SEL, GPIO_D_C, GPIO_BASE);		
	gpio_write(GPIO_MASKD_SEL, GPIO_MASK_EN, GPIO_BASE);
	gpio_write(GPIO_MASKC_SEL, GPIO_MASK_EN, GPIO_BASE);
	gpio_write(GPIO_SENS_SEL, GPIO_EDGE, GPIO_BASE);
	gpio_write(GPIO_LF_HR_SEL, GPIO_LOW_FALL, GPIO_BASE);
	gpio_write(GPIO_PDCON, GPIO_PDCON_OUTPUT, GPIO_BASE);
	gpio_write(GPIO_PCCON, GPIO_PCCON_INPUT, GPIO_BASE);
	//before_irq = gpio_read(GPIO_ISR, GPIO_BASE);
	/*	D->C trigger(falling edge)	*/
	gpio_write(GPIO_PDDR, GPIO_PDDR_DATA, GPIO_BASE);
	data_c = gpio_read(GPIO_PCDR, GPIO_BASE);
	//irq = gpio_read(GPIO_ISR, GPIO_BASE);
	data_d = gpio_read(GPIO_PDDR, GPIO_BASE);
	
	//printf("before irq = %0x\n", before_irq);
	printf("data c = %0x\n", data_c);
	//printf("irq = %0x\n", irq);
	printf("data d = %0x\n", data_d);

	return ret;
}

/*****************extern irq test*******************************/

extern int 
extern_irq_test(int autotest)					//select normal and not mask
{
	int ret = 0;
	gpio_write(GPIO_MODE_SEL, GPIO_NORMAL, GPIO_BASE);
	gpio_write(GPIO_MASK_SEL, GPIO_MASK_EN, GPIO_BASE);
	gpio_write(GPIO_MASKB_SEL, GPIO_MASK_EN, GPIO_BASE);
	ret = test_item_ctrl(&sensitive_container, autotest);
	return ret;
}

extern int 
level_sensitive_test(int autotest)					//select level sensitive
{
	int ret = 0;
	//level_flag = 1;
	gpio_write(GPIO_SENS_SEL, GPIO_LEVEL, GPIO_BASE);
	gpio_write(GPIO_SENSB_SEL, GPIO_LEVEL, GPIO_BASE);
	ret = test_item_ctrl(&fl_rh_container, autotest);
	return ret;
}

extern int 
edge_sensitive_test(int autotest)					//select edge sensitive
{
	int ret = 0;
	//level_flag = 1;
	gpio_write(GPIO_SENS_SEL, GPIO_EDGE, GPIO_BASE);
	gpio_write(GPIO_SENSB_SEL, GPIO_EDGE, GPIO_BASE);
	ret = test_item_ctrl(&single_both_container, autotest);
	return ret;
}

extern int 
single_sensitive_test(int autotest)					//select single sensitive
{
	int ret = 0;
	//level_flag = 1;
	gpio_write(GPIO_S_B_SEL, GPIO_SINGLE, GPIO_BASE);
	gpio_write(GPIO_S_B_SEL_B, GPIO_SINGLE, GPIO_BASE);
	ret = test_item_ctrl(&fl_rh_container, autotest);
	return ret;
}

extern int 
low_falling_sensitive_test(int autotest)				//low level or falling edge trigger
{	
	int ret = 0 ;
	gpio_write(GPIO_LF_HR_SEL, GPIO_LOW_FALL, GPIO_BASE);
	gpio_write(GPIO_LF_HRB_SEL, GPIO_LOW_FALL, GPIO_BASE);
	ret = test_item_ctrl(&low_falling_container, autotest);
	return ret;
}

extern int 
high_rising_sensitive_test(int autotest)				//high level or rising edge trigger
{
	int ret = 0;
	gpio_write(GPIO_LF_HR_SEL, GPIO_HIGH_RISE, GPIO_BASE);
	gpio_write(GPIO_LF_HRB_SEL, GPIO_HIGH_RISE, GPIO_BASE);
	ret = test_item_ctrl(&high_rising_container, autotest);
	return ret;
}

extern int 
low_falling_port_test(int autotest)
{
	int ret = 0;
	u32 data_a;	u32 irq_a;
	u32 irq_b;
	u32 data_b;
	//u32 irq_clr;
	//if(level_flag)
	//{
		//printf("low_level_trigger\n");
		gpio_write(GPIO_PACON, GPIO_PACON_INPUT, GPIO_BASE);
		gpio_write(GPIO_PADR, GPIO_DATA_CLR, GPIO_BASE);
		data_a = gpio_read(GPIO_PADR, GPIO_BASE);
		irq_a = gpio_read(GPIO_ISR, GPIO_BASE);
		printf("data a = %0x,irq a = %0x\n", data_a,irq_a);
		//gpio_write(GPIO_CLEAR_A, GPIO_CLEAR_SET, GPIO_BASE);
		/*irq_clr = gpio_read(GPIO_ISR, GPIO_BASE);printf("\nclear irq = %0x\n", irq_clr);*/
	/*level_flag = 0;
	}
	if(edge_flag)
	{
		printf("falling_edge_trigger\n");
		gpio_write(GPIO_PACON, GPIO_PACON_INPUT, GPIO_BASE);
		data_a = gpio_read(GPIO_PADR, GPIO_BASE);
		irq_a = gpio_read(GPIO_ISR, GPIO_BASE);
		printf("data a = %0x,irq a = %0x\n", data_a,irq_a);
		gpio_write(GPIO_CLEAR, GPIO_CLEAR_SET, GPIO_BASE);
	edge_flag = 0;
	}*/	
	gpio_write(GPIO_PBCON, GPIO_PBCON_INPUT, GPIO_BASE);
	gpio_write(GPIO_PBDR, GPIO_DATA_CLR, GPIO_BASE);
	data_b = gpio_read(GPIO_PBDR, GPIO_BASE);
	irq_b = gpio_read(GPIO_ISR, GPIO_BASE);
	printf("irq b = %0x,data b = %0x\n", irq_b,data_b);
	gpio_write(GPIO_CLEAR_A, GPIO_CLEAR_SET, GPIO_BASE);
	gpio_write(GPIO_CLEAR_B, GPIO_CLEAR_SET, GPIO_BASE);
	return ret;
}

extern int 
high_rising_port_test(int autotest)
{
	int ret = 0;
	u32 data_a;
	u32 irq_a;	
	u32 irq_b;
	u32 data_b;

	gpio_write(GPIO_PACON, GPIO_PACON_INPUT, GPIO_BASE);
	gpio_write(GPIO_PADR, GPIO_DATA_CLR, GPIO_BASE);
	data_a = gpio_read(GPIO_PADR, GPIO_BASE);
	irq_a = gpio_read(GPIO_ISR, GPIO_BASE);
	printf("data a = %0x,irq a = %0x\n", data_a,irq_a);
	//gpio_write(GPIO_CLEAR_A, GPIO_CLEAR_SET, GPIO_BASE);

	gpio_write(GPIO_PBCON, GPIO_PBCON_INPUT, GPIO_BASE);
	gpio_write(GPIO_PBDR, GPIO_DATA_CLR, GPIO_BASE);
	data_b = gpio_read(GPIO_PBDR, GPIO_BASE);
	irq_b = gpio_read(GPIO_ISR, GPIO_BASE);
	printf("irq b = %0x,data b = %0x\n", irq_b,data_b);
	gpio_write(GPIO_CLEAR_A, GPIO_CLEAR_SET, GPIO_BASE);
	gpio_write(GPIO_CLEAR_B, GPIO_CLEAR_SET, GPIO_BASE);
	return ret;
}

extern int 
both_sensitive_test(int autotest)
{
	int ret = 0;
	u32 irq_b;	
	u32 irq_a;
	
	gpio_write(GPIO_MODE_SEL, GPIO_NORMAL, GPIO_BASE);
	gpio_write(GPIO_MASK_SEL, GPIO_MASK_EN, GPIO_BASE);
	gpio_write(GPIO_SENS_SEL, GPIO_EDGE, GPIO_BASE);
	gpio_write(GPIO_S_B_SEL, GPIO_BOTH, GPIO_BASE);

	gpio_write(GPIO_PACON, GPIO_PACON_INPUT, GPIO_BASE);
	gpio_write(GPIO_PADR, GPIO_DATA_CLR, GPIO_BASE);

	irq_a = gpio_read(GPIO_ISR, GPIO_BASE);
	printf("irq a = %0x\n", irq_a);
	//gpio_write(GPIO_CLEAR_A, GPIO_CLEAR_SET, GPIO_BASE);

	gpio_write(GPIO_PBCON, GPIO_PBCON_INPUT, GPIO_BASE);
	gpio_write(GPIO_PBDR, GPIO_DATA_CLR, GPIO_BASE);

	irq_b = gpio_read(GPIO_ISR, GPIO_BASE);

	printf("irq b = %0x\n", irq_b);

	gpio_write(GPIO_CLEAR_A, GPIO_CLEAR_SET, GPIO_BASE);
	gpio_write(GPIO_CLEAR_B, GPIO_CLEAR_SET, GPIO_BASE);
	return ret;
}


































