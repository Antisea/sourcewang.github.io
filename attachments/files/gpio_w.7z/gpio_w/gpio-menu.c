#include <test_item.h>
#include "gpio-regs.h"
#include <global.h>
#include "dependency.h"

extern int test_mode_test(int autotest);
extern int normal_mode_test(int autotest);
extern int flash_led_test(int autotest);

struct test_item flash_led_items[] = {
{"flash led test",
 flash_led_test,
 1,
 1},
};

struct test_item_container flash_led_container = {
	.menu_name = "general test",
	.shell_name = "general",
	.items = flash_led_items,
	.test_item_size = sizeof(flash_led_items)
};


struct test_item general_items[] = {
{"test mode test",
 test_mode_test,
 1,
 1},
{"normal mode test",
 normal_mode_test,
 1,
 1}
};

struct test_item_container general_container = {
	.menu_name = "general test",
	.shell_name = "general",
	.items = general_items,
	.test_item_size = sizeof(general_items)
};


extern int without_interrupt_test(int autotest); 
extern int with_interrupt_test(int autotest);
extern int irq_type_select_test(int autotest);
extern int extern_irq_test(int autotest);
extern int inter_irq_test(int autotest);

struct test_item irq_items[] ={
{"without interrupt test",
 without_interrupt_test,
 1,
 1},
{"with interrupt test",
 irq_type_select_test,
 1,
 1}
};

struct test_item_container irq_container = {
	.menu_name = "irq_container",
	.shell_name = "irq",
	.items = irq_items,
	.test_item_size = sizeof(irq_items)
};

struct test_item irq_type_select_items[] = {
{"extern irq",
 extern_irq_test,
 1,
 1},
{"inter irq",
 inter_irq_test,
 1,
 1}
};

struct test_item_container irq_type_select_container = {
	.menu_name = "irq type select container",
	.shell_name = "irq type select",
	.items = irq_type_select_items,
	.test_item_size = sizeof(irq_type_select_items)
};

extern int port_item_test_1(int autotest);
extern int port_item_test_2(int autotest);
extern int port_item_test_3(int autotest);
extern int port_item_test_4(int autotest);

struct test_item port_items[] = {		//without irq
{"from b to a test",
 port_item_test_1,
1,
1},
{"from a to b test",
 port_item_test_2,
 1,
 1},
{"from d to c test",
 port_item_test_3,
 1,
 1},
{"from c to d test",
 port_item_test_4,
 1,
 1}
};

struct test_item_container port_container = {
	.menu_name = "0 port a-d",
	.shell_name = "port",
	.items = port_items,
	.test_item_size = sizeof(port_items)
};

extern int from_b_to_a_test(int autotest);
extern int from_a_to_b_test(int autotest);
extern int from_c_to_d_test(int autotest);
extern int from_d_to_c_test(int autotest);

struct test_item port_item_items[] = {			//inner irq
{"from b to a test",
 from_b_to_a_test,
 1,
 1},
{"from a to b test",
 from_a_to_b_test,
 1,
 1},
{"from d to c test",
 from_d_to_c_test,
 1,
 1},
{"from c to d test",
 from_c_to_d_test,
 1,
 1}
};

struct test_item_container port_item_container = {
	.menu_name = "port item container",
	.shell_name = "port item",
	.items = port_item_items,
	.test_item_size = sizeof(port_item_items)
};



extern int level_sensitive_test(int autotest);
extern int edge_sensitive_test(int autotest);

struct test_item sensitive_items[] = {			//level or edge
{"level sensitive",
 level_sensitive_test,
 1,
 1},
{"edge sensitive",
 edge_sensitive_test,
 1,
 1}
};

struct test_item_container sensitive_container = {
	.menu_name = "sensitive_container",
	.shell_name = "sensitive",
	.items = sensitive_items,
	.test_item_size = sizeof(sensitive_items)
};

extern int low_falling_sensitive_test(int autotest);
extern int high_rising_sensitive_test(int autotest);

struct test_item fl_rh_items[] = {
{"low level sensitive",
 low_falling_sensitive_test,
 1,
 1},
{"high level sensitive",
 high_rising_sensitive_test,
 1,
 1}
};

struct test_item_container fl_rh_container = {
	.menu_name = "fl_rh container",
	.shell_name = "fl and rh",
	.items = fl_rh_items,
	.test_item_size = sizeof(fl_rh_items)
};

extern int low_falling_port_test(int autotest);

struct test_item low_falling_items[] = {
{"low falling port a->d",
 low_falling_port_test,
 1,
 1}
};

struct test_item_container low_falling_container = {
	.menu_name = "low falling container",
	.shell_name = "low falling",
	.items = low_falling_items,
	.test_item_size = sizeof(low_falling_items) 
};

extern int high_rising_port_test(int autotest);

struct test_item high_rising_items[] = {
{"high rising port a->d",
 high_rising_port_test,
 1,
 1}
};

struct test_item_container high_rising_container = {
	.menu_name = "high rising container",
	.shell_name = "high rising",
	.items = high_rising_items,
	.test_item_size = sizeof(high_rising_items)
};

extern int single_sensitive_test(int autotest);
extern int both_sensitive_test(int autotest);

struct test_item single_both_items[] = {
{"single sensitive",
 single_sensitive_test,
 1,
 1},
{"both sensitive",
 both_sensitive_test,
 1,
 1}
};

struct test_item_container single_both_container = {
	.menu_name = "single both container",
	.shell_name = "single both",
	.items = single_both_items,
	.test_item_size = sizeof(single_both_items)
};




