




    /*     Registers for GPIO                */
 
#define SOCLE_GPIO_PADR 	0x0000  /* port  A  DATA register */
#define SOCLE_GPIO_PACON 	0x0004  /* port  A  direction register */
#define SOCLE_GPIO_PBDR 	0x0008  /* port  B  DATA register */
#define SOCLE_GPIO_PBCON 	0x000C  /* port  B  direction register */
#define SOCLE_GPIO_PCDR 	0x0010 	/* port  C  DATA register */
#define SOCLE_GPIO_PCCON 	0x0014	/* port  C  direction register */ 
#define SOCLE_GPIO_PDDR 	0x0018	/* port  D  DATA register */
#define SOCLE_GPIO_PDCON 	0x001C	/* port  D  direction register */ 

#define SOCLE_GPIO_TEST 	0x0020 	/* GPIO function test register */

/*   loop-back  mode test */
#define SOCLE_GPIO_MODE0 0X0001  	/*  loop-back test mode0 port B->A  */  
#define SOCLE_GPIO_MODE1 0x0003 	/*  loop-back test mode0 port A->B  */  
#define SOCLE_GPIO_MODE2 0x0005 	/*  loop-back test mode0 port D->C  */  
#define SOCLE_GPIO_MODE3 0x0007 	/*  loop-back test mode0 port C->D  */  

/*   normal mode test */
#define SOCLE_GPIO_MODE4 0x0000 


/*	VALUE	*/
#define SOCLE_GPIO_DATA0	0X5A
#define SOCLE_GPIO_DATA1	0XA5
#define SOCLE_GPIO_DATA2	0X0F
#define SOCLE_GPIO_DATA3	0X00
#define SOCLE_GPIO_DATA4	0XFF
#define SOCLE_GPIO_DATA5	0x1
#define SOCLE_GPIO_DATA6	0x80
#define SOCLE_GPIO_DATA7	0xaa



#define SOCLE_GPIO_OUTPUT	0XFF
#define SOCLE_GPIO_INPUT	0X00


 
/*   fpga interrupts    */
#define SOCLE_GPIO_IEA		0X0024   /*port A interrupt mask register  */
#define SOCLE_GPIO_IEB		0X0028   /*port B interrupt mask register  */
#define SOCLE_GPIO_IEC		0X002C   /*port C interrupt mask register  */ 
#define SOCLE_GPIO_IED		0X0030   /*port D interrupt mask register  */
#define SOCLE_GPIO_ISA		0X0034   /*port A interrupt sense register  */
#define SOCLE_GPIO_ISB		0X0038   /*port B interrupt sense register  */
#define SOCLE_GPIO_ISC		0X003C   /*port C interrupt sense register  */
#define SOCLE_GPIO_ISD		0X0040   /*port D interrupt sense register  */
#define SOCLE_GPIO_IBEA		0X0044   /*port A interrupt both-edges register  */
#define SOCLE_GPIO_IBEB		0X0048   /*port B interrupt both-edges register  */
#define SOCLE_GPIO_IBEC		0X004C   /*port C interrupt both-edges register  */
#define SOCLE_GPIO_IBED		0X0050 	 /*port D interrupt both-edges register  */
#define SOCLE_GPIO_IEVA		0X0054  /*port A interrupt event register  */
#define SOCLE_GPIO_IEVB		0X0058  /*port B interrupt event register  */
#define SOCLE_GPIO_IEVC		0X005C  /*port C interrupt event register  */
#define SOCLE_GPIO_IEVD		0X0060  /*port D interrupt event register  */
#define SOCLE_GPIO_ICA		0X0064  /*port A interrupt clear register  */
#define SOCLE_GPIO_ICB		0X0068  /*port B interrupt clear register  */
#define SOCLE_GPIO_ICC		0X006C  /*port C interrupt clear register  */
#define SOCLE_GPIO_ICD		0X0070  /*port D interrupt clear register  */
#define SOCLE_GPIO_ISR		0X0074  /*GPIO interrupt status register  */






/*	set a->d	*/
#define GPIO_MASK_SEL 		0X0024
#define GPIO_MASKB_SEL 		0X0028
#define GPIO_MASKC_SEL		0X002C
#define GPIO_MASKD_SEL		0X0030

#define GPIO_SENS_SEL 		0X0034
#define GPIO_SENSB_SEL 		0X0038
#define GPIO_SENSC_SEL		0X003c
#define GPIO_SENSD_SEL		0X0040

#define GPIO_S_B_SEL 		0X0044
#define GPIO_S_B_SEL_B 		0X0048
#define GPIO_S_B_SEL_C 		0X004c
#define GPIO_S_B_SEL_D 		0X0050

#define GPIO_LF_HR_SEL 		0X0054
#define GPIO_LF_HRB_SEL 	0X0058
#define GPIO_LF_HRC_SEL		0X005C
#define GPIO_LF_HRD_SEL		0X0060

#define GPIO_CLEAR_A 		0X0064
#define GPIO_CLEAR_B 		0X0068
#define GPIO_CLEAR_C 		0X006C
#define GPIO_CLEAR_D 		0X0070
#define GPIO_ISR 		0X0074
/*	register 0	*/
#define GPIO_LEVEL		0XFF
#define GPIO_EDGE		0X0
#define GPIO_SINGLE		0X0
#define GPIO_BOTH		0XFF
#define GPIO_LOW_FALL		0X0
#define GPIO_HIGH_RISE		0XFF
#define GPIO_CLEAR_SET		0XFF
/*	register 1	*/
#define GPIO_MASK_EN		0XFF
#define GPIO_SENS_LEVEL		0X0
#define GPIO_SENS_HIGH		0X1
//#define GPIO_SENS_EDGE		0X0
//#define GPIO_SENS_LOW		0X1

#define GPIO_MODE_SEL		0X0020

#define GPIO_PADR		0X0000
#define GPIO_PBDR		0X0008
#define GPIO_PCDR		0X0010
#define GPIO_PDDR		0X0018
#define GPIO_PACON		0X0004
#define GPIO_PBCON		0X000C
#define GPIO_PCCON		0X0014
#define GPIO_PDCON		0X001C
/*	set data	*/
#define GPIO_DATA_CLR		0X0
#define GPIO_PADR_DATA		0X5A
#define GPIO_PBDR_DATA		0XA5
#define GPIO_PCDR_DATA		0XAA
#define GPIO_PDDR_DATA		0X55
/*	set input-output	*/
#define GPIO_PACON_INPUT 	0X0
#define GPIO_PACON_OUTPUT 	0XFF
#define GPIO_PBCON_INPUT 	0X0
#define GPIO_PBCON_OUTPUT 	0XFF
#define GPIO_PCCON_INPUT 	0X0
#define GPIO_PCCON_OUTPUT 	0XFF
#define GPIO_PDCON_INPUT 	0X0
#define GPIO_PDCON_OUTPUT 	0XFF
/*	select normal or loopback	*/
#define GPIO_NORMAL		0X0		//turn leds
#define GPIO_A_B		0X3
#define GPIO_B_A		0X1
#define GPIO_C_D		0X7
#define GPIO_D_C		0X5

