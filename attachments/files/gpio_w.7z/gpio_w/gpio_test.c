/********************************************************************************
* File Name     : drivers/char/gpio_test.c
* Author        : cyli
* Description   : Pseudo GPIO Driver Test
*
* Copyright (C) Socle Tech. Corp.
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by the Free Software Foundation;
* either version 2 of the License, or (at your option) any later version.
* This program is distributed in the hope that it will be useful,  but WITHOUT ANY WARRANTY;
* without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

*   Version      : 2,0,0,1
*   History      :
*      1. 2006/09/27 cyli create this file
*
********************************************************************************/

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>

void menu(void);


static struct gpio_ioctl_data{
	unsigned char port;
	unsigned char mask;
	unsigned char data;
}ioctl_data;

#define	DRV_GPIO		(185)

//ioctl command
#define	SOCLE_GPIO_IN		_IOW(DRV_GPIO, 0, struct gpio_ioctl_data)
#define	SOCLE_GPIO_OUT		_IOR(DRV_GPIO, 1, struct gpio_ioctl_data)
#define	SOCLE_GPIO_DIR		_IOR(DRV_GPIO, 2, struct gpio_ioctl_data)

int main (int argc,	char *argv[])
{
	int fd, wdata, input, cmd;
	char dev[10], test_item, rdata;
	
	printf("Please input device node = ");
	scanf("%s", &dev);
	fgetc(stdin);
	
	if ((fd = open(dev, O_RDWR) ) < 0) {
		fprintf(stderr, "Can't open %s!\n", dev);
		return -1;
	}

	while(1){
		menu();
		test_item = fgetc(stdin);
		fgetc(stdin);
		
		switch(test_item){
		case '1':	//Read
			if(!read(fd, &rdata, 0xff)){
				fprintf(stderr, "read() error!\n");
				close(fd);
				return -1;
			}
			printf("rdata=%x\n", rdata);
			break;
			
		case '2':	//Write
			printf("Input write data = 0x");
			scanf("%x", &wdata);
			fgetc(stdin);
			
			if(!write(fd, &wdata, 0xff)){
				fprintf(stderr, "write() error!\n");
				close(fd);
				return -1;
			}
			break;
		
		case '3':	//Ioctl
			printf("1.SOCLE_GPIO_IN   2.SOCLE_GPIO_OUT   3.SOCLE_GPIO_DIR\n");
			printf("Select ioctl command = ");
			test_item = fgetc(stdin);
			fgetc(stdin);
			
			switch (test_item){
				case '1':
					cmd = SOCLE_GPIO_IN;
					break;
				case '2':
					cmd = SOCLE_GPIO_OUT;
					break;
				case '3':
					cmd = SOCLE_GPIO_DIR;
					break;
				default:
					printf("Retry again!!\n");
					continue;
			}
		
			printf("Input port(0~3) = ");
			scanf("%x", &input);
			fgetc(stdin);
			ioctl_data.port = (unsigned char)input;
			
			printf("Input mask = 0x");
			scanf("%x", &input);
			fgetc(stdin);
			ioctl_data.mask = (unsigned char)input;
			
			if(SOCLE_GPIO_IN != cmd){
				printf("Input data = 0x");
				scanf("%x", &input);
				fgetc(stdin);
				ioctl_data.data = (unsigned char)input;
			}
			
			//printf("port=%x mask=%x data=%x", ioctl_data.port, ioctl_data.mask ,ioctl_data.data);
			
			if(ioctl(fd, cmd, &ioctl_data)){
				fprintf(stderr, "ioctl() error!\n");
				close(fd);
				return -1;
			}
			
			if(SOCLE_GPIO_IN == cmd)
				printf("rdata = %x", ioctl_data.data);
			
			break;
			
		case 'x':
		case 'X':
			close(fd);
			printf("Exit program!\n");
			return 0;
		default:
			printf("Please select again! [%c]\n", test_item);
		}	
	}
	
}

void menu(void)
{
	printf("\n===== GPIO test =====\n");
	printf("1. Read GPIO\n");
	printf("2. Write GPIO\n");
	printf("3. Ioctl GPIO\n");
	printf("x. Exit program\n");
	printf("=====================\n\n");
}

